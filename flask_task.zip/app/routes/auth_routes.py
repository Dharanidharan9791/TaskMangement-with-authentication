from flask import Blueprint, request, jsonify
from app.models.user_model import create_user, get_user_by_email
from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    if get_user_by_email(db, data['email']):
        return jsonify({"error": "User already exists"}), 400

    hashed_password = generate_password_hash(data['password'])
    create_user(db, {
        "first_name": data['first_name'],
        "last_name": data['last_name'],
        "email": data['email'],
        "password": hashed_password
    })
    return jsonify({"message": "User registered successfully"}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = get_user_by_email(db, data['email'])

    if not user or not check_password_hash(user['password'], data['password']):
        return jsonify({"error": "Invalid credentials"}), 401

    access_token = create_access_token(identity=str(user['_id']))
    return jsonify({
        "access_token": access_token,
        "user_id": str(user['_id']),
        "company_id": "dummy_company_id"  # Replace with actual logic
    }), 200
