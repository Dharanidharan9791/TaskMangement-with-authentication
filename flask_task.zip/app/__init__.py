from flask import Flask
from flask_jwt_extended import JWTManager
from pymongo import MongoClient
from app.config import Config
from app.routes.auth_routes import auth_bp
from app.routes.lead_routes import lead_bp
from app.routes.task_routes import task_bp

# Initialize the app
app = Flask(__name__)
app.config.from_object(Config)

# JWT Setup
jwt = JWTManager(app)

# MongoDB Connection
client = MongoClient(app.config['MONGO_URI'])
db = client['task_manager']

# Register Blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(lead_bp)
app.register_blueprint(task_bp)
